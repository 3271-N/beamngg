import { useState, useEffect, useMemo } from 'react';
import { 
  Search, Download, Car, Map, Wrench, ExternalLink, Star, Users, Calendar,
  Heart, BarChart3, ChevronDown, Check, Zap,
  Menu, Github, Twitter, Youtube, MessageSquare,
  Gauge, Settings, Layers
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';

// Mod veri tipi
interface Mod {
  id: number;
  title: string;
  description: string;
  category: 'vehicle' | 'map' | 'other';
  subcategory?: string;
  image: string;
  author: string;
  downloads: string;
  rating: number;
  date: string;
  version: string;
  gameVersion: string;
  downloadUrl: string;
  sourceUrl: string;
  tags: string[];
  features?: string[];
  fileSize?: string;
}

// Kapsamlı Mod Veritabanı - 50+ Gerçek Mod
const modsData: Mod[] = [
  // === JDM / Japanese Cars ===
  {
    id: 1,
    title: 'Lexus LFA Nürburgring Edition',
    description: 'Efsanevi V10 sesi ve detaylı iç mekan ile Lexus LFA. 4.8L V10 motor, 562 beygir, karbon fiber gövde.',
    category: 'vehicle',
    subcategory: 'jdm',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/c9df2f66173dea5fa66b9530ec1b7d4937ce3852',
    author: 'BeamNG Community',
    downloads: '185,420',
    rating: 4.9,
    date: '2024',
    version: '4.2',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/lexus-lfa-nurburgring-edition.12944/',
    sourceUrl: 'https://www.beamng.com/resources/lexus-lfa-nurburgring-edition.12944/',
    tags: ['Supercar', 'JDM', 'V10', 'Track', 'Lexus'],
    features: ['Özel V10 sesi', 'Detaylı iç mekan', 'Aktif aerodinamik', 'Karbon fiber gövde'],
    fileSize: '245 MB'
  },
  {
    id: 2,
    title: 'Subaru WRX STI Hatchback',
    description: 'JDM efsanesi WRX STI hatchback. 2.5L turbo boxer motor, AWD, rally performansı.',
    category: 'vehicle',
    subcategory: 'jdm',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/3f292663217b1d830b6f647032f5c8079143a6ce',
    author: 'RallyMods',
    downloads: '127,890',
    rating: 4.7,
    date: '2024',
    version: '2.1',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.nexusmods.com/beamngdrive/mods/',
    sourceUrl: 'https://www.nexusmods.com/beamngdrive/mods/',
    tags: ['Hatchback', 'JDM', 'AWD', 'Turbo', 'Rally'],
    features: ['Boxer motor sesi', 'Rally süspansiyon', 'Türkiye plakası', 'Çoklu renk seçenekleri'],
    fileSize: '189 MB'
  },
  {
    id: 3,
    title: 'Mazda RX-7 FD Spirit R',
    description: 'Efsanevi rotary motorlu RX-7. 13B-REW motor, 276 beygir, drift için optimize edilmiş.',
    category: 'vehicle',
    subcategory: 'jdm',
    image: 'https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800',
    author: 'DriftKing',
    downloads: '234,567',
    rating: 4.8,
    date: '2025',
    version: '3.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Sports', 'JDM', 'Rotary', 'Drift', 'Mazda'],
    features: ['Rotary motor sesi', 'Drift ayarları', 'Pop-up farlar', 'RE Amemiya bodykit'],
    fileSize: '156 MB'
  },
  {
    id: 4,
    title: 'Toyota Supra MK4 2JZ',
    description: '2JZ-GTE motorlu efsane Supra. 1000+ beygir potansiyeli, drag ve street race için.',
    category: 'vehicle',
    subcategory: 'jdm',
    image: 'https://images.unsplash.com/photo-1626668893632-6f3d4466d22f?w=800',
    author: 'JDM Legends',
    downloads: '312,890',
    rating: 4.9,
    date: '2025',
    version: '2.5',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Sports', 'JDM', 'Turbo', 'Drag', 'Toyota'],
    features: ['2JZ motor sesi', '1000HP+ potansiyel', 'Targa tavan', 'Veilside bodykit'],
    fileSize: '198 MB'
  },
  {
    id: 5,
    title: 'Nissan Skyline R34 GT-R',
    description: 'Godzilla lakaplı efsane. RB26DETT motor, ATTESA E-TS AWD sistemi.',
    category: 'vehicle',
    subcategory: 'jdm',
    image: 'https://images.unsplash.com/photo-1619405399517-d7fce0f13302?w=800',
    author: 'NismoWorks',
    downloads: '298,456',
    rating: 4.8,
    date: '2024',
    version: '4.1',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Sports', 'JDM', 'AWD', 'Turbo', 'Nissan'],
    features: ['RB26 sesi', 'ATTESA AWD', 'Multifunction display', 'Nismo bodykit'],
    fileSize: '167 MB'
  },
  {
    id: 6,
    title: 'Honda NSX Type R',
    description: 'V6 VTEC motorlu süper spor. Formula 1 teknolojisi, Alüminyum şasi.',
    category: 'vehicle',
    subcategory: 'jdm',
    image: 'https://images.unsplash.com/photo-1605816988064-bb8b0f5b7b4d?w=800',
    author: 'HondaRacing',
    downloads: '145,230',
    rating: 4.7,
    date: '2024',
    version: '2.0',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Supercar', 'JDM', 'V6', 'Track', 'Honda'],
    features: ['VTEC sesi', 'Alüminyum şasi', 'Pop-up farlar', 'Type R ayarları'],
    fileSize: '134 MB'
  },
  {
    id: 7,
    title: 'Mitsubishi Lancer Evo IX',
    description: '4G63 motorlu ralli efsanesi. AWD, active yaw control, 280 beygir.',
    category: 'vehicle',
    subcategory: 'jdm',
    image: 'https://images.unsplash.com/photo-1617531653520-4893f7bbf978?w=800',
    author: 'RalliArt',
    downloads: '178,920',
    rating: 4.6,
    date: '2024',
    version: '1.8',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Sedan', 'JDM', 'AWD', 'Turbo', 'Rally'],
    features: ['4G63 sesi', 'AYC sistemi', 'Ralliart livery', 'Brembo frenler'],
    fileSize: '142 MB'
  },
  {
    id: 8,
    title: 'Toyota AE86 Trueno',
    description: 'Initial D efsanesi. 4A-GE motor, RWD, drift için ikonik.',
    category: 'vehicle',
    subcategory: 'jdm',
    image: 'https://images.unsplash.com/photo-1627740660376-bc70a795b3c8?w=800',
    author: 'DriftMaster',
    downloads: '267,340',
    rating: 4.8,
    date: '2025',
    version: '3.2',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Hatchback', 'JDM', 'RWD', 'Drift', 'Toyota'],
    features: ['4A-GE sesi', 'Pop-up farlar', 'Panda livery', 'TRD bodykit'],
    fileSize: '98 MB'
  },
  
  // === German Cars ===
  {
    id: 9,
    title: 'BMW M5 F90 Competition',
    description: '600+ beygirlik süper sedan. 4.4L V8 twin-turbo, xDrive AWD.',
    category: 'vehicle',
    subcategory: 'german',
    image: 'https://kimi-web-img.moonshot.cn/img/dlcfun.com/274a203f8e018d5c248f2ae8c22e17575e878711',
    author: 'DLCfun',
    downloads: '245,670',
    rating: 4.8,
    date: '2025',
    version: '2.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://dlcfun.com/en/beamng/avto-bmw-m5-f90-mod',
    sourceUrl: 'https://dlcfun.com/en/beamng/avto-bmw-m5-f90-mod',
    tags: ['Sedan', 'German', 'V8', 'Luxury', 'BMW'],
    features: ['S63 V8 sesi', 'xDrive AWD', 'M Sport paket', 'Carbon seramik frenler'],
    fileSize: '234 MB'
  },
  {
    id: 10,
    title: 'Audi R8 V10 Plus',
    description: '5.2L V10 naturally aspirated motor, 610 beygir, Quattro AWD.',
    category: 'vehicle',
    subcategory: 'german',
    image: 'https://images.unsplash.com/photo-1614200187524-dc411d9e62f5?w=800',
    author: 'AudiSport',
    downloads: '198,340',
    rating: 4.7,
    date: '2024',
    version: '3.1',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Supercar', 'German', 'V10', 'AWD', 'Audi'],
    features: ['V10 sesi', 'Quattro AWD', 'Laser farlar', 'Aerodinamik paket'],
    fileSize: '201 MB'
  },
  {
    id: 11,
    title: 'Mercedes-AMG GT R',
    description: '4.0L V8 biturbo, 585 beygir, Green Hell Magico.',
    category: 'vehicle',
    subcategory: 'german',
    image: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800',
    author: 'AMG Works',
    downloads: '156,780',
    rating: 4.6,
    date: '2024',
    version: '2.2',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Supercar', 'German', 'V8', 'Track', 'Mercedes'],
    features: ['M178 V8 sesi', 'Aktif aerodinamik', 'Green Hell renk', 'AMG Track Paket'],
    fileSize: '187 MB'
  },
  {
    id: 12,
    title: 'Porsche 911 GT3 RS (992)',
    description: '4.0L flat-6, 525 beygir, Nürburgring rekor sahibi.',
    category: 'vehicle',
    subcategory: 'german',
    image: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=800',
    author: 'PorscheClub',
    downloads: '289,450',
    rating: 4.9,
    date: '2025',
    version: '1.5',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.nexusmods.com/beamngdrive/mods/',
    sourceUrl: 'https://www.nexusmods.com/beamngdrive/mods/',
    tags: ['Supercar', 'German', 'Flat-6', 'Track', 'Porsche'],
    features: ['Boxer-6 sesi', 'DRS kanat', 'Weissach paket', 'Michelin Cup 2'],
    fileSize: '223 MB'
  },
  {
    id: 13,
    title: 'Audi A6 C8 S Line',
    description: 'Modern lüks sedan. 3.0L V6, mild hybrid, Quattro.',
    category: 'vehicle',
    subcategory: 'german',
    image: 'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?w=800',
    author: 'AudiMods',
    downloads: '87,340',
    rating: 4.5,
    date: '2025',
    version: '1.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Sedan', 'German', 'V6', 'Luxury', 'Audi'],
    features: ['Matrix LED farlar', 'Virtual cockpit', 'Bang & Olufsen', 'Hava süspansiyon'],
    fileSize: '156 MB'
  },
  {
    id: 14,
    title: 'BMW M3 G80',
    description: 'S58 motorlu yeni nesil M3. 510 beygir, RWD/AWD seçenekleri.',
    category: 'vehicle',
    subcategory: 'german',
    image: 'https://images.unsplash.com/photo-1655217417533-3d4400508c9d?w=800',
    author: 'BMWMotorsport',
    downloads: '134,560',
    rating: 4.6,
    date: '2024',
    version: '2.0',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Sedan', 'German', 'I6', 'Track', 'BMW'],
    features: ['S58 sesi', 'Büyük ızgara', 'Carbon paket', 'Drift analizör'],
    fileSize: '178 MB'
  },
  
  // === American Muscle ===
  {
    id: 15,
    title: 'Dodge Challenger SRT Hellcat',
    description: '6.2L supercharged HEMI, 717 beygir, drag strip kralı.',
    category: 'vehicle',
    subcategory: 'american',
    image: 'https://images.unsplash.com/photo-1592639296346-560c37a8f724?w=800',
    author: 'MoparOrNoCar',
    downloads: '234,890',
    rating: 4.8,
    date: '2025',
    version: '3.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Muscle', 'American', 'V8', 'Supercharged', 'Dodge'],
    features: ['Supercharger whine', '717HP', 'Widebody kit', 'Demon ayarları'],
    fileSize: '198 MB'
  },
  {
    id: 16,
    title: 'Ford Mustang GT 5.0',
    description: '5.0L Coyote V8, 450 beygir, modern muscle.',
    category: 'vehicle',
    subcategory: 'american',
    image: 'https://images.unsplash.com/photo-1584345604476-8ec5e12e42dd?w=800',
    author: 'FordPerformance',
    downloads: '198,340',
    rating: 4.7,
    date: '2024',
    version: '2.5',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Muscle', 'American', 'V8', 'RWD', 'Ford'],
    features: ['Coyote V8 sesi', 'Active exhaust', 'GT Performance paket', 'Recaro koltuklar'],
    fileSize: '167 MB'
  },
  {
    id: 17,
    title: 'Chevrolet Camaro ZL1',
    description: '6.2L supercharged LT4, 650 beygir, track focused.',
    category: 'vehicle',
    subcategory: 'american',
    image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800',
    author: 'ChevyMods',
    downloads: '176,540',
    rating: 4.6,
    date: '2024',
    version: '2.0',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Muscle', 'American', 'V8', 'Track', 'Chevrolet'],
    features: ['LT4 motor sesi', '1LE paket', 'Magnetic Ride', 'Performance Data Recorder'],
    fileSize: '182 MB'
  },
  {
    id: 18,
    title: 'Chevrolet Chevelle SS 1970',
    description: 'Klasik American muscle. 454 Big Block V8, 450 beygir.',
    category: 'vehicle',
    subcategory: 'american',
    image: 'https://images.unsplash.com/photo-1566008885218-90abf9200ddb?w=800',
    author: 'ClassicMuscle',
    downloads: '145,230',
    rating: 4.8,
    date: '2024',
    version: '1.5',
    gameVersion: '0.36+',
    downloadUrl: 'https://modshost.co/beamng/',
    sourceUrl: 'https://modshost.co/beamng/',
    tags: ['Classic', 'American', 'V8', 'Muscle', 'Chevrolet'],
    features: ['Big Block sesi', 'Klasik iç mekan', 'SS paket', 'Rally tekerlekleri'],
    fileSize: '134 MB'
  },
  {
    id: 19,
    title: 'Pontiac GTO Judge 1969',
    description: 'The Judge, 400 V8 Ram Air III, 366 beygir.',
    category: 'vehicle',
    subcategory: 'american',
    image: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=800',
    author: 'PontiacLegacy',
    downloads: '98,760',
    rating: 4.7,
    date: '2024',
    version: '1.2',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Classic', 'American', 'V8', 'Muscle', 'Pontiac'],
    features: ['Ram Air hood', 'Judge decal', 'Hurst shifter', 'Carousel kırmızısı'],
    fileSize: '112 MB'
  },
  {
    id: 20,
    title: 'Dodge Charger R/T 1969',
    description: 'General Lee tarzı klasik Charger. 440 Magnum V8.',
    category: 'vehicle',
    subcategory: 'american',
    image: 'https://images.unsplash.com/photo-1503376763036-066120622c74?w=800',
    author: 'MoparClassics',
    downloads: '187,450',
    rating: 4.8,
    date: '2025',
    version: '2.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Classic', 'American', 'V8', 'Muscle', 'Dodge'],
    features: ['440 Magnum sesi', 'Hidden headlights', 'Scat Pack', 'Side exhaust'],
    fileSize: '145 MB'
  },
  
  // === SUVs & Trucks ===
  {
    id: 21,
    title: 'Lamborghini Urus Performante',
    description: 'Super SUV. 4.0L V8 twin-turbo, 666 beygir, 0-100 3.3s.',
    category: 'vehicle',
    subcategory: 'suv',
    image: 'https://kimi-web-img.moonshot.cn/img/cs2.worldofmods.com/5e594e56cac04de123a65c7341869a537b3267b9.jpg',
    author: 'LamboMods',
    downloads: '267,890',
    rating: 4.7,
    date: '2025',
    version: '2.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.nexusmods.com/beamngdrive/mods/',
    sourceUrl: 'https://www.nexusmods.com/beamngdrive/mods/',
    tags: ['SUV', 'Italian', 'V8', 'Luxury', 'Lamborghini'],
    features: ['V8 twin-turbo sesi', 'Off-road modları', 'Carbon fiber kaput', 'Akrapoviç egzoz'],
    fileSize: '234 MB'
  },
  {
    id: 22,
    title: 'Ford F-150 Raptor R',
    description: '5.2L supercharged V8, 700 beygir, off-road canavarı.',
    category: 'vehicle',
    subcategory: 'truck',
    image: 'https://images.unsplash.com/photo-1551830820-330a71b99659?w=800',
    author: 'FordTrucks',
    downloads: '198,450',
    rating: 4.8,
    date: '2025',
    version: '1.5',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Truck', 'American', 'V8', 'Off-road', 'Ford'],
    features: ['Supercharged V8', 'Fox Racing süspansiyon', '37 inch lastikler', 'Baja modu'],
    fileSize: '245 MB'
  },
  {
    id: 23,
    title: 'Jeep Wrangler Rubicon 392',
    description: '6.4L HEMI V8, 470 beygir, ultimate off-road.',
    category: 'vehicle',
    subcategory: 'suv',
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=800',
    author: 'JeepNation',
    downloads: '156,780',
    rating: 4.6,
    date: '2024',
    version: '2.0',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['SUV', 'American', 'V8', 'Off-road', 'Jeep'],
    features: ['HEMI V8 sesi', 'Solid axle', 'Locking differential', 'Winch'],
    fileSize: '198 MB'
  },
  {
    id: 24,
    title: 'Mercedes-Benz G63 AMG',
    description: '4.0L V8 biturbo, 585 beygir, lüks off-road.',
    category: 'vehicle',
    subcategory: 'suv',
    image: 'https://images.unsplash.com/photo-1520031441872-265e4ff70366?w=800',
    author: 'AMGMods',
    downloads: '178,920',
    rating: 4.7,
    date: '2024',
    version: '2.5',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['SUV', 'German', 'V8', 'Luxury', 'Mercedes'],
    features: ['AMG V8 sesi', '3 differential', '22 inch jantlar', 'Designo iç mekan'],
    fileSize: '212 MB'
  },
  
  // === Rally & Race Cars ===
  {
    id: 25,
    title: 'Ford Fiesta WRC 2017',
    description: '1.6L turbo, 380 beygir, 4WD, WRC spec.',
    category: 'vehicle',
    subcategory: 'rally',
    image: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800',
    author: 'WRCMods',
    downloads: '134,560',
    rating: 4.8,
    date: '2024',
    version: '2.0',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Rally', 'Race', 'Turbo', 'AWD', 'Ford'],
    features: ['WRC ses paketi', 'Aktif diferansiyel', 'Gravel/Tarmac ayarları', 'M-Sport livery'],
    fileSize: '156 MB'
  },
  {
    id: 26,
    title: 'Lancia Delta HF Integrale',
    description: 'Group A efsanesi. 2.0L turbo, 210 beygir, 4WD.',
    category: 'vehicle',
    subcategory: 'rally',
    image: 'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?w=800',
    author: 'RallyLegends',
    downloads: '167,340',
    rating: 4.9,
    date: '2025',
    version: '3.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Rally', 'Classic', 'Turbo', 'AWD', 'Lancia'],
    features: ['Martini livery', 'Group A sesi', 'Körük şarj', 'Safari ayarları'],
    fileSize: '134 MB'
  },
  {
    id: 27,
    title: 'Audi Quattro S1 E2',
    description: 'Group B efsanesi. 2.1L turbo, 470 beygir, 4WD.',
    category: 'vehicle',
    subcategory: 'rally',
    image: 'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800',
    author: 'GroupBForever',
    downloads: '198,760',
    rating: 4.9,
    date: '2025',
    version: '2.5',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Rally', 'Group B', 'Turbo', 'AWD', 'Audi'],
    features: ['5 silindir sesi', 'Dev kanatlar', 'HB Audi Team livery', 'Pikes Peak versiyonu'],
    fileSize: '145 MB'
  },
  {
    id: 28,
    title: 'Toyota GR Yaris Rally1',
    description: '2024 WRC aracı. 1.6L turbo hybrid, 500 beygir.',
    category: 'vehicle',
    subcategory: 'rally',
    image: 'https://images.unsplash.com/photo-1621007947382-bb3c3968e3bb?w=800',
    author: 'ToyotaGazoo',
    downloads: '145,230',
    rating: 4.7,
    date: '2025',
    version: '1.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Rally', 'WRC', 'Hybrid', 'AWD', 'Toyota'],
    features: ['Hybrid sesi', 'GR-Four AWD', '2024 livery', 'Sprint modu'],
    fileSize: '167 MB'
  },
  
  // === Korean Cars ===
  {
    id: 29,
    title: 'Kia Stinger GT',
    description: '3.3L V6 twin-turbo, 365 beygir. Stock, Bodykit ve Police versiyonları.',
    category: 'vehicle',
    subcategory: 'korean',
    image: 'https://kimi-web-img.moonshot.cn/img/staticdelivery.nexusmods.com/812543c6eedf00643a18d342001f442efbdf10b9.png',
    author: 'viddemannen',
    downloads: '312,780',
    rating: 4.8,
    date: '2024',
    version: '3.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.nexusmods.com/beamngdrive/mods/4',
    sourceUrl: 'https://www.nexusmods.com/beamngdrive/mods/4',
    tags: ['Sedan', 'Korean', 'V6', 'Turbo', 'Kia'],
    features: ['V6 twin-turbo sesi', 'RWD/AWD', 'Police versiyonu', 'Bodykit seçenekleri'],
    fileSize: '178 MB'
  },
  {
    id: 30,
    title: 'Hyundai i30 N',
    description: '2.0L turbo, 275 beygir, Nürburgring test edilmiş.',
    category: 'vehicle',
    subcategory: 'korean',
    image: 'https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800',
    author: 'NPerformance',
    downloads: '98,450',
    rating: 4.6,
    date: '2024',
    version: '2.0',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Hatchback', 'Korean', 'Turbo', 'FWD', 'Hyundai'],
    features: ['N exhaust sesi', 'e-LSD', 'Performance Blue', 'N Grin Shift'],
    fileSize: '134 MB'
  },
  
  // === HYPERCARS ===
  {
    id: 31,
    title: 'Bugatti Chiron Super Sport',
    description: '8.0L W16 quad-turbo, 1600 beygir, 440 km/h+ top speed.',
    category: 'vehicle',
    subcategory: 'hypercar',
    image: 'https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800',
    author: 'HypercarMods',
    downloads: '234,560',
    rating: 4.9,
    date: '2025',
    version: '2.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Hypercar', 'French', 'W16', 'Speed', 'Bugatti'],
    features: ['W16 sesi', '1500+ HP', 'Top speed test', 'La Voiture Noire skin'],
    fileSize: '267 MB'
  },
  {
    id: 32,
    title: 'Koenigsegg Jesko Attack',
    description: '5.0L V8 twin-turbo, 1600 beygir, 300 mph+ potansiyel.',
    category: 'vehicle',
    subcategory: 'hypercar',
    image: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=800',
    author: 'KoenigseggFan',
    downloads: '187,340',
    rating: 4.8,
    date: '2025',
    version: '1.5',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Hypercar', 'Swedish', 'V8', 'Track', 'Koenigsegg'],
    features: ['Light Speed Transmission', 'Aktif kanat', 'Ghost paket', '9-speed gearbox'],
    fileSize: '234 MB'
  },
  {
    id: 33,
    title: 'McLaren P1 GTR',
    description: '3.8L V8 twin-turbo hybrid, 1000 beygir, track only.',
    category: 'vehicle',
    subcategory: 'hypercar',
    image: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800',
    author: 'McLarenMods',
    downloads: '156,780',
    rating: 4.7,
    date: '2024',
    version: '2.0',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Hypercar', 'British', 'Hybrid', 'Track', 'McLaren'],
    features: ['IPAS boost', 'DRS kanat', 'GTR livery', 'Track telemetry'],
    fileSize: '198 MB'
  },
  
  // === MAPS ===
  {
    id: 34,
    title: 'Motorsports Playground',
    description: 'Devasa motorsport kompleksi. Drag, drift, oval, rallycross, monster truck ve daha fazlası.',
    category: 'map',
    subcategory: 'racing',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/73a4f5e8213d84a8c592e5acdfd36ffffac55222',
    author: 'TrackMaster',
    downloads: '1,245,890',
    rating: 4.9,
    date: '2024',
    version: '5.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/motorsports-playground.21834/',
    sourceUrl: 'https://www.beamng.com/resources/motorsports-playground.21834/',
    tags: ['Racing', 'Multi-purpose', 'Large', 'Tracks', 'Drift'],
    features: ['Drag strip (1/4 mile)', 'Oval track', 'Rallycross', 'Drift course', 'Monster truck arena'],
    fileSize: '1.2 GB'
  },
  {
    id: 35,
    title: 'Beam Mountains',
    description: 'Rocky Mountains esintili devasa dağ haritası. Drift yolları ve off-road parkurları.',
    category: 'map',
    subcategory: 'mountain',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/ab15a599817db2db018e887c0291f5211482a909',
    author: 'MountainDew',
    downloads: '678,340',
    rating: 4.8,
    date: '2024',
    version: '4.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/beam-mountains.1951/',
    sourceUrl: 'https://www.beamng.com/resources/beam-mountains.1951/',
    tags: ['Mountain', 'Drift', 'Off-road', 'Scenic', 'Large'],
    features: ['50km+ yol', 'Karlı zirveler', 'Dağ köyleri', 'Off-road parkurları'],
    fileSize: '2.1 GB'
  },
  {
    id: 36,
    title: 'Project BeamNG.rally',
    description: '28 etaplık devasa rally projesi. 240km+ ralli yolu, pace notes desteği.',
    category: 'map',
    subcategory: 'rally',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/8371fa5586be935574f881bd9cefd083e267360b',
    author: 'TrackBroseff',
    downloads: '2,456,780',
    rating: 4.9,
    date: '2025',
    version: '2.3',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/project-beamng-rally.29149/',
    sourceUrl: 'https://www.beamng.com/resources/project-beamng-rally.29149/',
    tags: ['Rally', 'Racing', 'Stages', 'Simulation', 'Competition'],
    features: ['28 unique stages', 'Pace notes', 'Service parks', 'Group B/4 araçları', 'Online competition'],
    fileSize: '3.5 GB'
  },
  {
    id: 37,
    title: 'West Coast USA Highways',
    description: '20+ km ekstra otoyol ve demiryolu. Arkadaşlarınızla yarış için mükemmel.',
    category: 'map',
    subcategory: 'highway',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/7a4c18ee361af7e86ed5912b37a0721d1389e8b2',
    author: 'K8',
    downloads: '456,230',
    rating: 4.7,
    date: '2024',
    version: '3.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/west-coast-usa-highways-and-railways.23456/',
    sourceUrl: 'https://www.beamng.com/resources/west-coast-usa-highways-and-railways.23456/',
    tags: ['Highway', 'USA', 'Racing', 'Expansion', 'Multiplayer'],
    features: ['20km+ highway', 'AI traffic paths', 'Bus route 177', 'Tunnels', 'Interchanges'],
    fileSize: '890 MB'
  },
  {
    id: 38,
    title: 'ToughTruckMap Off-Road',
    description: 'Zorlu off-road deneyimi. Kaya tırmanışı, derin çamur parkurları.',
    category: 'map',
    subcategory: 'offroad',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/6fefcf9edf4845a35e28182b5460b1d93bc30604',
    author: 'OffRoadKing',
    downloads: '234,560',
    rating: 4.6,
    date: '2023',
    version: '2.5',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Off-road', 'Crawling', 'Mud', 'Challenge', 'Trucks'],
    features: ['Rock crawling', 'Mud pits', 'Water crossings', 'Steep hills', 'Winch points'],
    fileSize: '1.1 GB'
  },
  {
    id: 39,
    title: 'Italy Rework Night',
    description: 'Italy haritası gece versiyonu. Trenler, trafik ışıkları, gece aydınlatması.',
    category: 'map',
    subcategory: 'city',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/95d917208608cfbc7e1da69c5694893e3c13f160',
    author: 'ItalyTeam',
    downloads: '567,890',
    rating: 4.8,
    date: '2024',
    version: '2.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/threads/italy-rework-night-support-trains-traffic-lights.93855/',
    sourceUrl: 'https://www.beamng.com/threads/italy-rework-night-support-trains-traffic-lights.93855/',
    tags: ['City', 'Italy', 'Night', 'Realistic', 'Scenic'],
    features: ['Night lighting', 'Working trains', 'Traffic lights', 'Coastal roads', 'Tunnels'],
    fileSize: '1.8 GB'
  },
  {
    id: 40,
    title: 'Naorl OffRoad Adventure',
    description: 'Off-road macera haritası. Patikalar, kaya tırmanışı ve rally rotaları.',
    category: 'map',
    subcategory: 'offroad',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/968c54b80e75be681b9ef496d5069fe74b718666',
    author: 'Naorl',
    downloads: '189,340',
    rating: 4.5,
    date: '2024',
    version: '3.0',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Off-road', 'Adventure', 'Rally', 'Exploration', 'Trails'],
    features: ['Forest trails', 'Rock gardens', 'River crossings', 'Campsites', 'Lookout points'],
    fileSize: '756 MB'
  },
  {
    id: 41,
    title: 'Pikes Peak LIDAR Edition',
    description: 'Gerçek LIDAR verisiyle oluşturulmuş Pikes Peak dağı. Hill climb için.',
    category: 'map',
    subcategory: 'mountain',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/968c54b80e75be681b9ef496d5069fe74b718666',
    author: 'PikesPeakTeam',
    downloads: '345,670',
    rating: 4.8,
    date: '2024',
    version: '2.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/pikes-peak-lidar-edition.4986/',
    sourceUrl: 'https://www.beamng.com/resources/pikes-peak-lidar-edition.4986/',
    tags: ['Mountain', 'Hill Climb', 'Racing', 'Realistic', 'Pikes Peak'],
    features: ['19.99km yol', '156 viraj', 'LIDAR accuracy', 'Realistic scenery', 'Clouds at summit'],
    fileSize: '1.5 GB'
  },
  {
    id: 42,
    title: 'Flood Escape Mountain',
    description: 'Su baskını kaçış haritası. Zamanla yükselen su seviyesi.',
    category: 'map',
    subcategory: 'special',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/8371fa5586be935574f881bd9cefd083e267360b',
    author: 'FloodTeam',
    downloads: '278,450',
    rating: 4.7,
    date: '2024',
    version: '1.5',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/flood-escape-mountain.32145/',
    sourceUrl: 'https://www.beamng.com/resources/flood-escape-mountain.32145/',
    tags: ['Special', 'Challenge', 'Survival', 'Dynamic', 'Mountain'],
    features: ['Rising water', 'Time challenge', 'Multiple routes', 'Checkpoints', 'Leaderboard'],
    fileSize: '678 MB'
  },
  
  // === OTHER MODS ===
  {
    id: 43,
    title: 'Agent\'s Realistic Traffic Mod',
    description: '43+ Avrupa ve 14+ Japon aracı. Gerçekçi trafik simülasyonu.',
    category: 'other',
    subcategory: 'traffic',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/95d917208608cfbc7e1da69c5694893e3c13f160',
    author: 'AgentMooshroom5',
    downloads: '1,567,890',
    rating: 4.9,
    date: '2025',
    version: '3.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://drive.google.com/file/d/1ssj9vQzlS-UBPUrdwdsng52tenc019bP/view',
    sourceUrl: 'https://www.beamng.com/threads/agents-simplified-realistic-traffic-mod.102034/',
    tags: ['Traffic', 'AI', 'Realism', 'Performance', 'Vehicles'],
    features: ['57+ vehicles', 'EU/JP/US packs', 'Traffic tool', 'License plates', 'Random colors'],
    fileSize: '2.3 GB'
  },
  {
    id: 44,
    title: 'Meo\'s Drag Parts Pack',
    description: 'Drag yarışı için parça paketi. Tekerlekler, paraşütler, nitro sistemi.',
    category: 'other',
    subcategory: 'parts',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/1c137b0047d6d41ce66029daa27b9bf1f318bb84',
    author: 'Meo',
    downloads: '567,340',
    rating: 4.8,
    date: '2025',
    version: '3.0.18',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/meos-drag-parts-pack.21013/',
    sourceUrl: 'https://www.beamng.com/resources/meos-drag-parts-pack.21013/',
    tags: ['Drag', 'Parts', 'Performance', 'Tuning', 'Racing'],
    features: ['Drag wheels', 'Parachutes', '5000kW nitrous', 'Drag suspension', 'Radiator upgrades'],
    fileSize: '156 MB'
  },
  {
    id: 45,
    title: 'Global Odometer',
    description: 'Her araç konfigürasyonu için kilometre sayacı. Bağımsız kayıt.',
    category: 'other',
    subcategory: 'utility',
    image: 'https://kimi-web-img.moonshot.cn/img/staticdelivery.nexusmods.com/03478bd7eaa2b36904502a95e2c704a5bdb3da92.png',
    author: 'UtilityMods',
    downloads: '89,450',
    rating: 4.5,
    date: '2024',
    version: '1.1',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/global-odometer.25000/',
    sourceUrl: 'https://www.beamng.com/resources/global-odometer.25000/',
    tags: ['Utility', 'UI', 'Stats', 'Tool', 'Tracking'],
    features: ['Per-vehicle tracking', 'Persistent data', 'UI app', 'Export data', 'Multiple units'],
    fileSize: '12 MB'
  },
  {
    id: 46,
    title: 'Beta BGM Player',
    description: 'Oyunda arka planda müzik çalma. Özel playlist oluşturma.',
    category: 'other',
    subcategory: 'utility',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/6fefcf9edf4845a35e28182b5460b1d93bc30604',
    author: 'BGMTeam',
    downloads: '234,560',
    rating: 4.4,
    date: '2025',
    version: '1.0.2',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/beta-bgm-player.24000/',
    sourceUrl: 'https://www.beamng.com/resources/beta-bgm-player.24000/',
    tags: ['Music', 'UI', 'Entertainment', 'Tool', 'Audio'],
    features: ['Custom playlists', 'Folder support', 'Shuffle mode', 'Volume control', 'In-game UI'],
    fileSize: '8 MB'
  },
  {
    id: 47,
    title: 'Backfire Afterfire Mod',
    description: 'Özelleştirilebilir egzoz patlamaları ve alevler.',
    category: 'other',
    subcategory: 'effects',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/73a4f5e8213d84a8c592e5acdfd36ffffac55222',
    author: 'EffectsMaster',
    downloads: '445,670',
    rating: 4.7,
    date: '2024',
    version: '2.5',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/backfire-afterfire-mod.6475/',
    sourceUrl: 'https://www.beamng.com/resources/backfire-afterfire-mod.6475/',
    tags: ['Effects', 'Visual', 'Audio', 'Exhaust', 'Tuning'],
    features: ['Custom flames', 'Adjustable timing', 'Per-vehicle settings', 'Color options', 'Sound effects'],
    fileSize: '23 MB'
  },
  {
    id: 48,
    title: 'Advanced Driver Assistance Systems',
    description: 'ADAS sistemi. Adaptif cruise control, şerit takip, çarpışma önleme.',
    category: 'other',
    subcategory: 'systems',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/ab15a599817db2db018e887c0291f5211482a909',
    author: 'angelo234',
    downloads: '678,230',
    rating: 4.8,
    date: '2024',
    version: '2.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/advanced-driver-assistance-systems.20000/',
    sourceUrl: 'https://www.beamng.com/resources/advanced-driver-assistance-systems.20000/',
    tags: ['Systems', 'AI', 'Safety', 'Realism', 'Technology'],
    features: ['Adaptive cruise', 'Lane keep assist', 'Emergency braking', 'Blind spot monitor', 'Traffic sign recognition'],
    fileSize: '45 MB'
  },
  {
    id: 49,
    title: 'Traffic Tool Pro',
    description: 'Gelişmiş trafik yönetim aracı. Trafik yoğunluğu, davranış ayarları.',
    category: 'other',
    subcategory: 'traffic',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/7a4c18ee361af7e86ed5912b37a0721d1389e8b2',
    author: 'TrafficTools',
    downloads: '312,780',
    rating: 4.6,
    date: '2024',
    version: '1.5',
    gameVersion: '0.36+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Traffic', 'Tool', 'AI', 'Management', 'Control'],
    features: ['Density control', 'Speed limits', 'Vehicle types', 'Route editing', 'Spawn points'],
    fileSize: '18 MB'
  },
  {
    id: 50,
    title: 'Realistic Damage Mod',
    description: 'Gerçekçi hasar fizikleri. Parçalanma, bükülme, malzeme simülasyonu.',
    category: 'other',
    subcategory: 'physics',
    image: 'https://kimi-web-img.moonshot.cn/img/www.beamng.com/6fefcf9edf4845a35e28182b5460b1d93bc30604',
    author: 'PhysicsTeam',
    downloads: '892,340',
    rating: 4.9,
    date: '2025',
    version: '3.0',
    gameVersion: '0.37+',
    downloadUrl: 'https://www.beamng.com/resources/',
    sourceUrl: 'https://www.beamng.com/resources/',
    tags: ['Physics', 'Damage', 'Realism', 'Simulation', 'Graphics'],
    features: ['Material deformation', 'Part detachment', 'Realistic crumpling', 'Glass shattering', 'Fire effects'],
    fileSize: '67 MB'
  }
];

// Kategoriler
const categories = [
  { id: 'all', label: 'Tümü', icon: Layers },
  { id: 'vehicle', label: 'Araçlar', icon: Car },
  { id: 'map', label: 'Haritalar', icon: Map },
  { id: 'other', label: 'Modlar', icon: Wrench },
];

const subcategories = {
  vehicle: [
    { id: 'all', label: 'Tüm Araçlar' },
    { id: 'jdm', label: 'JDM' },
    { id: 'german', label: 'German' },
    { id: 'american', label: 'American' },
    { id: 'korean', label: 'Korean' },
    { id: 'hypercar', label: 'Hypercar' },
    { id: 'rally', label: 'Rally' },
    { id: 'suv', label: 'SUV' },
    { id: 'truck', label: 'Truck' },
  ],
  map: [
    { id: 'all', label: 'Tüm Haritalar' },
    { id: 'racing', label: 'Racing' },
    { id: 'mountain', label: 'Mountain' },
    { id: 'offroad', label: 'Off-Road' },
    { id: 'highway', label: 'Highway' },
    { id: 'city', label: 'City' },
    { id: 'special', label: 'Special' },
  ],
  other: [
    { id: 'all', label: 'Tüm Modlar' },
    { id: 'traffic', label: 'Traffic' },
    { id: 'parts', label: 'Parts' },
    { id: 'utility', label: 'Utility' },
    { id: 'effects', label: 'Effects' },
    { id: 'systems', label: 'Systems' },
    { id: 'physics', label: 'Physics' },
  ]
};

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'vehicle' | 'map' | 'other'>('all');
  const [activeSubcategory, setActiveSubcategory] = useState('all');
  const [selectedMod, setSelectedMod] = useState<Mod | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [favorites, setFavorites] = useState<number[]>([]);
  const [compareList, setCompareList] = useState<number[]>([]);
  const [showFavorites, setShowFavorites] = useState(false);
  const [showCompare, setShowCompare] = useState(false);
  const [sortBy, setSortBy] = useState<'downloads' | 'rating' | 'date'>('downloads');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Favorileri localStorage'dan yükle
  useEffect(() => {
    const saved = localStorage.getItem('beamng_favorites');
    if (saved) setFavorites(JSON.parse(saved));
  }, []);

  // Favorileri kaydet
  useEffect(() => {
    localStorage.setItem('beamng_favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Filtreleme ve sıralama
  const filteredMods = useMemo(() => {
    let mods = modsData.filter(mod => {
      const matchesSearch = mod.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           mod.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           mod.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())) ||
                           mod.author.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = activeCategory === 'all' || mod.category === activeCategory;
      const matchesSubcategory = activeSubcategory === 'all' || mod.subcategory === activeSubcategory;
      const matchesFavorites = !showFavorites || favorites.includes(mod.id);
      return matchesSearch && matchesCategory && matchesSubcategory && matchesFavorites;
    });

    // Sıralama
    mods.sort((a, b) => {
      if (sortBy === 'downloads') {
        return parseInt(b.downloads.replace(/[^0-9]/g, '')) - parseInt(a.downloads.replace(/[^0-9]/g, ''));
      } else if (sortBy === 'rating') {
        return b.rating - a.rating;
      } else {
        return parseInt(b.date) - parseInt(a.date);
      }
    });

    return mods;
  }, [searchQuery, activeCategory, activeSubcategory, favorites, showFavorites, sortBy]);

  // Favori toggle
  const toggleFavorite = (e: React.MouseEvent, modId: number) => {
    e.stopPropagation();
    setFavorites(prev => 
      prev.includes(modId) ? prev.filter(id => id !== modId) : [...prev, modId]
    );
    toast.success(favorites.includes(modId) ? 'Favorilerden çıkarıldı' : 'Favorilere eklendi');
  };

  // Karşılaştırma listesine ekle/çıkar
  const toggleCompare = (e: React.MouseEvent, modId: number) => {
    e.stopPropagation();
    if (compareList.includes(modId)) {
      setCompareList(prev => prev.filter(id => id !== modId));
    } else if (compareList.length < 3) {
      setCompareList(prev => [...prev, modId]);
      toast.success('Karşılaştırma listesine eklendi');
    } else {
      toast.error('En fazla 3 mod karşılaştırabilirsiniz');
    }
  };

  // İndirme fonksiyonu
  const handleDownload = (mod: Mod) => {
    toast.success(`${mod.title} indiriliyor...`, {
      description: 'Mod sayfasına yönlendiriliyorsunuz.',
    });
    window.open(mod.downloadUrl, '_blank');
  };

  // Detay görüntüleme
  const openModDetails = (mod: Mod) => {
    setSelectedMod(mod);
    setIsDialogOpen(true);
  };

  // İstatistikler
  const stats = useMemo(() => ({
    totalMods: modsData.length,
    totalDownloads: modsData.reduce((acc, mod) => acc + parseInt(mod.downloads.replace(/[^0-9]/g, '')), 0),
    avgRating: (modsData.reduce((acc, mod) => acc + mod.rating, 0) / modsData.length).toFixed(1),
    vehicleCount: modsData.filter(m => m.category === 'vehicle').length,
    mapCount: modsData.filter(m => m.category === 'map').length,
    otherCount: modsData.filter(m => m.category === 'other').length,
  }), []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-black/95 backdrop-blur-md border-b-2 border-[#ff6600]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Car className="h-8 w-8 text-[#ff6600]" />
              <span className="text-xl font-bold tracking-wider">
                BEAM<span className="text-[#ff6600]">NG</span> MOD HUB
              </span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-6">
              <button onClick={() => { setActiveCategory('all'); setActiveSubcategory('all'); setShowFavorites(false); }} className="text-gray-300 hover:text-[#ff6600] transition-colors">Anasayfa</button>
              <button onClick={() => { setActiveCategory('vehicle'); setActiveSubcategory('all'); setShowFavorites(false); }} className="text-gray-300 hover:text-[#ff6600] transition-colors">Araçlar</button>
              <button onClick={() => { setActiveCategory('map'); setActiveSubcategory('all'); setShowFavorites(false); }} className="text-gray-300 hover:text-[#ff6600] transition-colors">Haritalar</button>
              <button onClick={() => { setActiveCategory('other'); setActiveSubcategory('all'); setShowFavorites(false); }} className="text-gray-300 hover:text-[#ff6600] transition-colors">Modlar</button>
              <button 
                onClick={() => setShowFavorites(true)} 
                className={`flex items-center gap-1 transition-colors ${showFavorites ? 'text-[#ff6600]' : 'text-gray-300 hover:text-[#ff6600]'}`}
              >
                <Heart className="h-4 w-4" />
                Favoriler ({favorites.length})
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-black border-t border-gray-800">
            <div className="px-4 py-4 space-y-3">
              <button onClick={() => { setActiveCategory('all'); setMobileMenuOpen(false); }} className="block w-full text-left text-gray-300 py-2">Anasayfa</button>
              <button onClick={() => { setActiveCategory('vehicle'); setMobileMenuOpen(false); }} className="block w-full text-left text-gray-300 py-2">Araçlar</button>
              <button onClick={() => { setActiveCategory('map'); setMobileMenuOpen(false); }} className="block w-full text-left text-gray-300 py-2">Haritalar</button>
              <button onClick={() => { setActiveCategory('other'); setMobileMenuOpen(false); }} className="block w-full text-left text-gray-300 py-2">Modlar</button>
              <button onClick={() => { setShowFavorites(true); setMobileMenuOpen(false); }} className="block w-full text-left text-gray-300 py-2">Favoriler ({favorites.length})</button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-[#0a0a0a]">
          <img 
            src="https://images.unsplash.com/photo-1511919884226-fd3cad34687c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80"
            alt="Hero Background"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="relative z-20 text-center px-4 max-w-5xl mx-auto">
          <Badge className="mb-4 bg-[#ff6600]/20 text-[#ff6600] border-[#ff6600]/50 px-4 py-1">
            <Zap className="w-3 h-3 mr-1" />
            50+ Premium Mod
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Sınırları <span className="text-[#ff6600]">Zorlayan</span><br />
            <span className="bg-gradient-to-r from-[#ff6600] to-yellow-500 bg-clip-text text-transparent">
              Modlar
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto">
            En gerçekçi araçlar, devasa haritalar ve profesyonel modlar. 
            Topluluk tarafından seçilmiş, test edilmiş.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-[#ff6600] hover:bg-[#e55c00] text-white px-8 py-6 text-lg"
              onClick={() => document.getElementById('mods-section')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <Download className="mr-2 h-5 w-5" />
              Modları Keşfet
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-[#ff6600] text-[#ff6600] hover:bg-[#ff6600] hover:text-white px-8 py-6 text-lg"
              onClick={() => window.open('https://www.beamng.com/resources/', '_blank')}
            >
              <ExternalLink className="mr-2 h-5 w-5" />
              BeamNG Resmi
            </Button>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20 animate-bounce">
          <ChevronDown className="h-8 w-8 text-[#ff6600]" />
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-gradient-to-r from-[#111] via-[#1a1a1a] to-[#111] border-y border-gray-800">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center hover:scale-105 transition-transform">
              <div className="text-4xl md:text-5xl font-bold text-[#ff6600] mb-1">{stats.totalMods}+</div>
              <div className="text-gray-400 flex items-center justify-center gap-1">
                <Layers className="w-4 h-4" /> Premium Mod
              </div>
            </div>
            <div className="text-center hover:scale-105 transition-transform">
              <div className="text-4xl md:text-5xl font-bold text-[#ff6600] mb-1">{(stats.totalDownloads / 1000000).toFixed(1)}M+</div>
              <div className="text-gray-400 flex items-center justify-center gap-1">
                <Download className="w-4 h-4" /> İndirme
              </div>
            </div>
            <div className="text-center hover:scale-105 transition-transform">
              <div className="text-4xl md:text-5xl font-bold text-[#ff6600] mb-1">{stats.avgRating}</div>
              <div className="text-gray-400 flex items-center justify-center gap-1">
                <Star className="w-4 h-4" /> Ortalama Puan
              </div>
            </div>
            <div className="text-center hover:scale-105 transition-transform">
              <div className="text-4xl md:text-5xl font-bold text-[#ff6600] mb-1">100%</div>
              <div className="text-gray-400 flex items-center justify-center gap-1">
                <Check className="w-4 h-4" /> Güncel Modlar
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section id="mods-section" className="py-16 max-w-7xl mx-auto px-4">
        {/* Search and Filter Bar */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
            {/* Search */}
            <div className="relative w-full lg:w-96">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Mod ara... (örn: BMW, Drift, Rally, JDM)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-[#1a1a1a] border-gray-700 text-white placeholder:text-gray-500 focus:border-[#ff6600] focus:ring-[#ff6600]"
              />
            </div>

            {/* Main Categories */}
            <Tabs value={activeCategory} onValueChange={(v) => { setActiveCategory(v as any); setActiveSubcategory('all'); setShowFavorites(false); }} className="w-full lg:w-auto">
              <TabsList className="bg-[#1a1a1a] border border-gray-700 flex-wrap h-auto">
                {categories.map(cat => (
                  <TabsTrigger 
                    key={cat.id} 
                    value={cat.id}
                    className="data-[state=active]:bg-[#ff6600] data-[state=active]:text-white flex items-center gap-1"
                  >
                    <cat.icon className="h-4 w-4" />
                    {cat.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>

          {/* Subcategories */}
          {activeCategory !== 'all' && !showFavorites && (
            <div className="flex flex-wrap gap-2 animate-fadeIn">
              {subcategories[activeCategory]?.map(sub => (
                <button
                  key={sub.id}
                  onClick={() => setActiveSubcategory(sub.id)}
                  className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                    activeSubcategory === sub.id 
                      ? 'bg-[#ff6600] text-white' 
                      : 'bg-[#1a1a1a] text-gray-400 hover:bg-gray-800'
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>
          )}

          {/* Sort and Results Count */}
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="text-gray-400">
              <span className="text-[#ff6600] font-bold">{filteredMods.length}</span> mod bulundu
            </div>
            <div className="flex items-center gap-2">
              <span className="text-gray-400 text-sm">Sırala:</span>
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-[#1a1a1a] border border-gray-700 text-white rounded px-3 py-1 text-sm focus:border-[#ff6600] focus:outline-none"
              >
                <option value="downloads">İndirme Sayısı</option>
                <option value="rating">Puan</option>
                <option value="date">Yeni Eklenen</option>
              </select>
            </div>
          </div>
        </div>

        {/* Mod Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredMods.map((mod) => (
            <Card 
              key={mod.id} 
              className="bg-[#1a1a1a] border-gray-800 hover:border-[#ff6600] transition-all duration-300 hover:transform hover:-translate-y-2 overflow-hidden group cursor-pointer h-full flex flex-col"
              onClick={() => openModDetails(mod)}
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={mod.image} 
                  alt={mod.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                
                {/* Category Badge */}
                <div className="absolute top-2 left-2">
                  <Badge className="bg-black/70 text-white border-0 text-xs">
                    {mod.category === 'vehicle' && <Car className="mr-1 h-3 w-3" />}
                    {mod.category === 'map' && <Map className="mr-1 h-3 w-3" />}
                    {mod.category === 'other' && <Wrench className="mr-1 h-3 w-3" />}
                    {mod.category === 'vehicle' ? 'Araç' : mod.category === 'map' ? 'Harita' : 'Mod'}
                  </Badge>
                </div>

                {/* Action Buttons */}
                <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => toggleFavorite(e, mod.id)}
                    className={`p-2 rounded-full transition-colors ${
                      favorites.includes(mod.id) 
                        ? 'bg-red-500 text-white' 
                        : 'bg-black/70 text-white hover:bg-red-500'
                    }`}
                  >
                    <Heart className="h-4 w-4" fill={favorites.includes(mod.id) ? 'currentColor' : 'none'} />
                  </button>
                  <button
                    onClick={(e) => toggleCompare(e, mod.id)}
                    className={`p-2 rounded-full transition-colors ${
                      compareList.includes(mod.id) 
                        ? 'bg-[#ff6600] text-white' 
                        : 'bg-black/70 text-white hover:bg-[#ff6600]'
                    }`}
                  >
                    <BarChart3 className="h-4 w-4" />
                  </button>
                </div>

                {/* File Size */}
                {mod.fileSize && (
                  <div className="absolute bottom-2 right-2">
                    <span className="text-xs bg-black/70 text-white px-2 py-1 rounded">
                      {mod.fileSize}
                    </span>
                  </div>
                )}
              </div>

              <CardHeader className="pb-2 flex-grow">
                <CardTitle className="text-lg text-white line-clamp-1 group-hover:text-[#ff6600] transition-colors">
                  {mod.title}
                </CardTitle>
                <CardDescription className="text-gray-400 line-clamp-2 text-sm">
                  {mod.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="pb-2">
                <div className="flex flex-wrap gap-1 mb-3">
                  {mod.tags.slice(0, 3).map((tag, idx) => (
                    <span key={idx} className="text-xs bg-gray-800 text-gray-300 px-2 py-0.5 rounded">
                      {tag}
                    </span>
                  ))}
                  {mod.tags.length > 3 && (
                    <span className="text-xs bg-gray-800 text-gray-400 px-2 py-0.5 rounded">
                      +{mod.tags.length - 3}
                    </span>
                  )}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1 text-yellow-500">
                    <Star className="h-4 w-4 fill-current" />
                    <span className="font-semibold">{mod.rating}</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-400">
                    <Download className="h-4 w-4" />
                    <span>{mod.downloads}</span>
                  </div>
                </div>
              </CardContent>

              <CardFooter className="pt-0">
                <Button 
                  className="w-full bg-[#ff6600] hover:bg-[#e55c00] text-white"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDownload(mod);
                  }}
                >
                  <Download className="mr-2 h-4 w-4" />
                  İndir
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {filteredMods.length === 0 && (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold text-white mb-2">Sonuç bulunamadı</h3>
            <p className="text-gray-400">Arama kriterlerinize uygun mod bulunamadı.</p>
            <Button 
              className="mt-4 bg-[#ff6600] hover:bg-[#e55c00]"
              onClick={() => { setSearchQuery(''); setActiveCategory('all'); setActiveSubcategory('all'); }}
            >
              Filtreleri Temizle
            </Button>
          </div>
        )}
      </section>

      {/* Compare Modal */}
      <Dialog open={showCompare} onOpenChange={setShowCompare}>
        <DialogContent className="max-w-4xl bg-[#1a1a1a] border-gray-700 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl flex items-center gap-2">
              <BarChart3 className="h-6 w-6 text-[#ff6600]" />
              Mod Karşılaştırma
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {compareList.map(modId => {
              const mod = modsData.find(m => m.id === modId);
              if (!mod) return null;
              return (
                <div key={mod.id} className="bg-[#111] rounded-lg p-4">
                  <img src={mod.image} alt={mod.title} className="w-full h-32 object-cover rounded mb-3" />
                  <h3 className="font-bold text-lg mb-2">{mod.title}</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Puan:</span>
                      <span className="text-yellow-500">⭐ {mod.rating}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">İndirme:</span>
                      <span>{mod.downloads}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Boyut:</span>
                      <span>{mod.fileSize}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Versiyon:</span>
                      <span>{mod.version}</span>
                    </div>
                  </div>
                  <Button 
                    className="w-full mt-3 bg-[#ff6600] hover:bg-[#e55c00]"
                    onClick={() => handleDownload(mod)}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    İndir
                  </Button>
                </div>
              );
            })}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCompareList([])} className="border-gray-600">
              Listeyi Temizle
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Mod Details Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        {selectedMod && (
          <DialogContent className="max-w-3xl bg-[#1a1a1a] border-gray-700 text-white max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center gap-2 flex-wrap">
                {selectedMod.title}
                <Badge className="bg-[#ff6600]">
                  {selectedMod.category === 'vehicle' ? 'Araç' : selectedMod.category === 'map' ? 'Harita' : 'Mod'}
                </Badge>
              </DialogTitle>
              <DialogDescription className="text-gray-400">
                {selectedMod.description}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <img 
                src={selectedMod.image} 
                alt={selectedMod.title}
                className="w-full h-64 object-cover rounded-lg"
              />
              
              {/* Quick Stats */}
              <div className="grid grid-cols-4 gap-2">
                <div className="bg-[#111] p-3 rounded-lg text-center">
                  <Star className="h-5 w-5 text-yellow-500 mx-auto mb-1" />
                  <div className="text-lg font-bold">{selectedMod.rating}</div>
                  <div className="text-xs text-gray-400">Puan</div>
                </div>
                <div className="bg-[#111] p-3 rounded-lg text-center">
                  <Download className="h-5 w-5 text-[#ff6600] mx-auto mb-1" />
                  <div className="text-lg font-bold">{selectedMod.downloads}</div>
                  <div className="text-xs text-gray-400">İndirme</div>
                </div>
                <div className="bg-[#111] p-3 rounded-lg text-center">
                  <Calendar className="h-5 w-5 text-blue-500 mx-auto mb-1" />
                  <div className="text-lg font-bold">{selectedMod.date}</div>
                  <div className="text-xs text-gray-400">Yıl</div>
                </div>
                <div className="bg-[#111] p-3 rounded-lg text-center">
                  <Gauge className="h-5 w-5 text-green-500 mx-auto mb-1" />
                  <div className="text-lg font-bold">{selectedMod.fileSize}</div>
                  <div className="text-xs text-gray-400">Boyut</div>
                </div>
              </div>

              {/* Detailed Info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#111] p-3 rounded-lg">
                  <div className="text-gray-400 text-sm mb-1">Yapımcı</div>
                  <div className="text-white font-semibold flex items-center gap-2">
                    <Users className="h-4 w-4 text-[#ff6600]" />
                    {selectedMod.author}
                  </div>
                </div>
                <div className="bg-[#111] p-3 rounded-lg">
                  <div className="text-gray-400 text-sm mb-1">Versiyon</div>
                  <div className="text-white font-semibold flex items-center gap-2">
                    <Settings className="h-4 w-4 text-[#ff6600]" />
                    {selectedMod.version}
                  </div>
                </div>
                <div className="bg-[#111] p-3 rounded-lg">
                  <div className="text-gray-400 text-sm mb-1">Oyun Versiyonu</div>
                  <div className="text-white font-semibold flex items-center gap-2">
                    <Zap className="h-4 w-4 text-[#ff6600]" />
                    {selectedMod.gameVersion}
                  </div>
                </div>
                <div className="bg-[#111] p-3 rounded-lg">
                  <div className="text-gray-400 text-sm mb-1">Kategori</div>
                  <div className="text-white font-semibold flex items-center gap-2">
                    <Layers className="h-4 w-4 text-[#ff6600]" />
                    {selectedMod.subcategory?.toUpperCase()}
                  </div>
                </div>
              </div>

              {/* Features */}
              {selectedMod.features && (
                <div>
                  <div className="text-gray-400 text-sm mb-2">Özellikler</div>
                  <div className="grid grid-cols-2 gap-2">
                    {selectedMod.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 bg-[#111] p-2 rounded">
                        <Check className="h-4 w-4 text-green-500" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tags */}
              <div>
                <div className="text-gray-400 text-sm mb-2">Etiketler</div>
                <div className="flex flex-wrap gap-2">
                  {selectedMod.tags.map((tag, idx) => (
                    <Badge key={idx} variant="outline" className="border-gray-600 text-gray-300">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <DialogFooter className="gap-2">
              <Button 
                variant="outline" 
                onClick={() => window.open(selectedMod.sourceUrl, '_blank')}
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Kaynak
              </Button>
              <Button 
                onClick={() => handleDownload(selectedMod)}
                className="bg-[#ff6600] hover:bg-[#e55c00] text-white"
              >
                <Download className="mr-2 h-4 w-4" />
                Modu İndir
              </Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>

      {/* Installation Guide */}
      <section className="py-16 bg-gradient-to-b from-[#111] to-[#0a0a0a]">
        <div className="max-w-5xl mx-auto px-4">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-[#ff6600]/20 text-[#ff6600] border-[#ff6600]/50">
              <Wrench className="w-3 h-3 mr-1" />
              Kurulum Rehberi
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold">
              Mod <span className="text-[#ff6600]">Nasıl Yüklenir?</span>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { 
                step: 1, 
                title: 'Modu İndir', 
                desc: 'İstediğin modu seç ve .zip dosyasını indir. Dosyayı açmana gerek yok.',
                icon: Download
              },
              { 
                step: 2, 
                title: 'Klasöre Kopyala', 
                desc: 'İndirilen dosyayı Documents/BeamNG.drive/mods klasörüne kopyala.',
                icon: Layers
              },
              { 
                step: 3, 
                title: 'Oyuna Başla', 
                desc: 'Oyunu başlat ve Mod Manager\'dan modu etkinleştir. Hazırsın!',
                icon: Check
              },
            ].map((item, idx) => (
              <div key={idx} className="text-center hover:scale-105 transition-transform">
                <div className="w-20 h-20 bg-gradient-to-br from-[#ff6600] to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-orange-500/30">
                  <item.icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-[#ff6600] font-bold text-lg mb-2">Adım {item.step}</div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-400">{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Pro Tip */}
          <div className="mt-12 bg-[#1a1a1a] border border-[#ff6600]/30 rounded-lg p-6 flex items-start gap-4">
            <div className="bg-[#ff6600]/20 p-3 rounded-full">
              <Zap className="h-6 w-6 text-[#ff6600]" />
            </div>
            <div>
              <h4 className="font-bold text-lg mb-1">Pro İpucu</h4>
              <p className="text-gray-400">
                Çok fazla mod yüklediğinde performans sorunları yaşayabilirsin. 
                <span className="text-[#ff6600]"> Mod Manager</span>'dan aktif olmayan modları devre dışı bırakmayı unutma!
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Floating Compare Button */}
      {compareList.length > 0 && (
        <div className="fixed bottom-6 right-6 z-50 animate-bounce">
          <Button
            size="lg"
            className="bg-[#ff6600] hover:bg-[#e55c00] shadow-lg shadow-orange-500/30"
            onClick={() => setShowCompare(true)}
          >
            <BarChart3 className="mr-2 h-5 w-5" />
            Karşılaştır ({compareList.length})
          </Button>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-black py-12 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Car className="h-6 w-6 text-[#ff6600]" />
                <span className="text-lg font-bold">
                  BEAM<span className="text-[#ff6600]">NG</span> MOD HUB
                </span>
              </div>
              <p className="text-gray-400 text-sm">
                BeamNG.drive için en kapsamlı mod arşivi. Gerçek modlar, çalışan linkler, profesyonel arayüz.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Hızlı Linkler</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><button onClick={() => setActiveCategory('vehicle')} className="hover:text-[#ff6600]">Araç Modları</button></li>
                <li><button onClick={() => setActiveCategory('map')} className="hover:text-[#ff6600]">Harita Modları</button></li>
                <li><button onClick={() => setActiveCategory('other')} className="hover:text-[#ff6600]">Diğer Modlar</button></li>
                <li><button onClick={() => setShowFavorites(true)} className="hover:text-[#ff6600]">Favorilerim</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Kaynaklar</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="https://www.beamng.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#ff6600]">BeamNG Forum</a></li>
                <li><a href="https://www.nexusmods.com/beamngdrive" target="_blank" rel="noopener noreferrer" className="hover:text-[#ff6600]">Nexus Mods</a></li>
                <li><a href="https://modshost.co/beamng" target="_blank" rel="noopener noreferrer" className="hover:text-[#ff6600]">ModsHost</a></li>
                <li><a href="https://www.worldofmods.com/beamng" target="_blank" rel="noopener noreferrer" className="hover:text-[#ff6600]">World of Mods</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">İletişim</h4>
              <div className="flex gap-3">
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-[#ff6600] transition-colors">
                  <Twitter className="h-5 w-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-[#ff6600] transition-colors">
                  <Youtube className="h-5 w-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-[#ff6600] transition-colors">
                  <Github className="h-5 w-5" />
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-[#ff6600] transition-colors">
                  <MessageSquare className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-400 text-sm">
              © 2026 BeamNG Mod Hub - Bu site bir hayran yapımıdır.
            </p>
            <p className="text-gray-500 text-xs mt-1">
              BeamNG.drive ve ilgili tüm markalar BeamNG GmbH'ye aittir.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
